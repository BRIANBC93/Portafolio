export class ToolsLanguages{
  nombre:string;
  imagen:string;
  estado:number;

  constructor() {
    this.nombre = "";
    this.imagen="#";
    this.estado = 0;
  }
}
