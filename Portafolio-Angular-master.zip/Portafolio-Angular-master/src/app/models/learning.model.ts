export class Learning {
  titulo: string;
  imagen: string;

  constructor() {
    this.titulo = "";
    this.imagen = "";
  }

}
