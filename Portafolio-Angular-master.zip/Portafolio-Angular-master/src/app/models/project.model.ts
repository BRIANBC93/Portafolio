export class Project {
  titulo: string;
  lenguaje: string;
  descripcion: string;
  imagen: string;
  imagen2: string;
  url: string;

  constructor() {
    this.titulo = "";
    this.lenguaje = "";
    this.descripcion = "";
    this.imagen = "";
    this.imagen2 = "";
    this.url;
  }

}
