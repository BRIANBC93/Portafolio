export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyCPo7JTRBbDoU2yIbhbTNREWACO7xlkMew",
    authDomain: "portafolioangular-4f64f.firebaseapp.com",
    databaseURL: "https://portafolioangular-4f64f.firebaseio.com",
    projectId: "portafolioangular-4f64f",
    storageBucket: "portafolioangular-4f64f.appspot.com",
    messagingSenderId: "465578885884",
    appId: "1:465578885884:web:ce4edca29843abe4940d79",
    measurementId: "G-7C4MYXWBW9"
  }
};
